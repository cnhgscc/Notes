# xadmin1.11.x
xadmin1.11.x分之版本备份

安装教程：

1. 下载文件，将xadmin复制到自己的项目中

2. [Django1.11.1使用xadmin的方法（一： 快速安装篇）](http://www.jianshu.com/p/65f9ee3d192d)

3. [Django1.11.1使用xadmin的方法（二： 简单配置篇）](http://www.jianshu.com/p/7b5a6282a96b)
